# Dolphin Admin Core

Universe core utils and plugins for Dolphin Admin.

## License

MIT
