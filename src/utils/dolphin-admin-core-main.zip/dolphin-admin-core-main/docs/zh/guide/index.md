# 介绍

## Dolphin Admin

Dolphin Admin 是一个基于 `TypeScript` 的**全栈后台管理系统**。

## 为什么不是 JavaScript？

- `TypeScript` 具有静态类型检查，可以在编码阶段捕获错误。
- `TypeScript` 编译器支持更好（包括代码补全、类型检查、重构等）。
- `TypeScript` 相较于 `JavaScript` 代码维护性更强。
- `TypeScript` 具有更好的面向对象编程支持。
