# 团队介绍

## 核心成员

### Bruce Song

![Bruce Song](https://avatars.githubusercontent.com/u/62941121?s=40&v=4)

[Dolphin Admin](https://dolphin-admin-react.bit-ocean.studio) 的作者，[Bit Ocean](https://github.com/bit-ocean-studio/) 组织的创建者。

> 目前专注于 React 和 React Native 的开源生态
