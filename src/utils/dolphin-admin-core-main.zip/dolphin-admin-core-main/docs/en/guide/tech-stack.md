# Tech Stack

## React

- React 18
- TypeScript
- Vite
- antd 5
- React Router
- Zustand
- Tanstack Query

## Vue

- Vue 3
- TypeScript
- Vite
- Naive UI
- Vue Router
- Pinia
- Tanstack Query

## Nest

- Nest
- TypeScript
- Prisma
- PostgreSQL
