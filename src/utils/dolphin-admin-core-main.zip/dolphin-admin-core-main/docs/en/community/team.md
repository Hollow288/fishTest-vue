# Team

## Core member

![Bruce Song](https://avatars.githubusercontent.com/u/62941121?s=40&v=4)

Bruce: The author of [Dolphin Admin](https://dolphin-admin-react.bit-ocean.studio) and the founder of [Bit Ocean](https://github.com/bit-ocean-studio/) Org.

> Now focusing on React & React Native Open Source ecosystem.
