# 启动动画

## 前端

`@dolphin-admin/bootstrap-animation` 提供了一个 Vite 插件用于显示启动动画，支持自定义应用名称、作者、描述等。

## 后端

Nest 的启动动画基于 `@dolphin-admin/bootstrap-animation` 提供的函数。
