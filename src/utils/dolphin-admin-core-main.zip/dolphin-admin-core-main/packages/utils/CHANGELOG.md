# @dolphin-admin/utils

## 0.0.23

### Patch Changes

- add time utils

## 0.0.22

### Patch Changes

- remove i18n utils

## 0.0.21

### Patch Changes

- extract enums to independent dir

## 0.0.20

### Patch Changes

- fix function type export

## 0.0.19

### Patch Changes

- add i18n utils

## 0.0.18

### Patch Changes

- AuthUtils add refresh token

## 0.0.17

### Patch Changes

- migrate to vite v5

## 0.0.16

### Patch Changes

- fix bad release

## 0.0.15

### Patch Changes

- LangUtils add setHtmlLang method

## 0.0.14

### Patch Changes

- update utils

## 0.0.13

### Patch Changes

- fix theme utils not export

## 0.0.12

### Patch Changes

- fix lang utils not export

## 0.0.11

### Patch Changes

- add auth and lang utils

## 0.0.10

### Patch Changes

- fix typo

## 0.0.9

### Patch Changes

- fix BrowserUtils static methods bug
- 9b8b273: add methods in BrowserUtils

## 0.0.8

### Patch Changes

- add methods in BrowserUtils

## 0.0.7

### Patch Changes

- browserUtils add disableGestureScale method

## 0.0.6

### Patch Changes

- update code base

## 0.0.5

### Patch Changes

- update type

## 0.0.4

### Patch Changes

- add antd auto import

## 0.0.3

### Patch Changes

- add auto import plugin

## 0.0.2

### Patch Changes

- add timeformatter type

## 0.0.1

### Patch Changes

- init utils
