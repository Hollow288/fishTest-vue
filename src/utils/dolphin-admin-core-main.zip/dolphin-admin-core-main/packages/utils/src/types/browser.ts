export interface ScrollOptions {
  element: HTMLElement
  target: number
  duration?: number
  animationFrameId?: number | null
}
