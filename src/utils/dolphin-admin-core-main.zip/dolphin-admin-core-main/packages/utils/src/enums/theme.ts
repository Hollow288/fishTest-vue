/**
 * 主题
 * @enum
 * - `light` - 亮色主题
 * - `dark` - 暗色主题
 */
export enum Theme {
  LIGHT = 'light',
  DARK = 'dark'
}
