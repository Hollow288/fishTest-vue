/**
 * 语言
 * @enum
 * - `zh-CN` - 简体中文
 * - `en-US` - 英语
 */
export enum Lang {
  'zh-CN' = 'zh-CN',
  'en-US' = 'en-US'
}
