# @dolphin-admin/bootstrap-animation

## 0.0.6

### Patch Changes

- add i18n utils

## 0.0.5

### Patch Changes

- migrate to vite v5

## 0.0.4

### Patch Changes

- add warp for animation

## 0.0.3

### Patch Changes

- add auth and lang utils

## 0.0.2

### Patch Changes

- update

## 0.0.1

### Patch Changes

- update
