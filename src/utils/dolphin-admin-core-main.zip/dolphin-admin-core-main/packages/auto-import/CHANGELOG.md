# @dolphin-admin/auto-import

## 0.0.12

### Patch Changes

- add i18n utils

## 0.0.11

### Patch Changes

- migrate to vite v5

## 0.0.10

### Patch Changes

- update auto import

## 0.0.9

### Patch Changes

- add auth and lang utils

## 0.0.8

### Patch Changes

- update

## 0.0.7

### Patch Changes

- update

## 0.0.6

### Patch Changes

- update code base

## 0.0.5

### Patch Changes

- update type

## 0.0.4

### Patch Changes

- add antd auto import

## 0.0.3

### Patch Changes

- add auto import plugin
